package com.example.tiskakarate;

public class Video_model {
    public String getVideo_url() {
        return video_url;
    }

    public void setVideo_url(String video_url) {
        this.video_url = video_url;
    }

    String video_url;
}
